import torch
import triton
import triton.language as tl
import triton.runtime.driver as driver
import torch_npu

AUTOTUNE_CONFIGS = [
    triton.Config({'BLOCK_M': 128, 'BLOCK_N': 256, 'BLOCK_K': 256}),
]

@triton.autotune(
    configs=AUTOTUNE_CONFIGS,
    key=['M', 'N', 'K'],
)
@triton.jit
def gemm_aw_fuse_kernel(
    a_in, a_out, b_in, b_out, c, M, N, K,
    stride_am, stride_ak,
    stride_cm, stride_cn,
    BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr,
    CORE_NUM: tl.constexpr,
    half_block_m: tl.constexpr,
    half_block_k: tl.constexpr,
    NEED_SPLIT_A: tl.constexpr,
    NEED_SPLIT_B: tl.constexpr,
):
    pid = tl.program_id(0)
    
    # ========== Phase 1: A and B Matrix Conversion ==========
    m_div_block_m = M // BLOCK_M
    k_div_block_k = K // BLOCK_K
    n_div_block_n = N // BLOCK_N
    
    # First convert A matrix
    if NEED_SPLIT_A:
        total_a_convert_blocks = m_div_block_m * k_div_block_k * 2
    else:
        total_a_convert_blocks = m_div_block_m * k_div_block_k
    
    for convert_block_idx in range(pid, total_a_convert_blocks, CORE_NUM):
        if NEED_SPLIT_A:
            pair_idx = convert_block_idx // 2
            m_idx = pair_idx // k_div_block_k
            k_idx = pair_idx % k_div_block_k
            
            in_m_offset = m_idx * BLOCK_M + (convert_block_idx % 2) * half_block_m
            out_offset = (m_idx * k_div_block_k + k_idx) * BLOCK_M * BLOCK_K
            
            in_block_ptr = tl.make_block_ptr(
                base=a_in,
                shape=(M, K),
                strides=(stride_am, stride_ak),
                offsets=(in_m_offset, k_idx * BLOCK_K),
                block_shape=(half_block_m, BLOCK_K),
                order=(1, 0)
            )
            
            out_block_ptr = tl.make_block_ptr(
                base=a_out + out_offset,
                shape=(BLOCK_M, BLOCK_K),
                strides=(BLOCK_K, 1),
                offsets=((convert_block_idx % 2) * half_block_m, 0),
                block_shape=(half_block_m, BLOCK_K),
                order=(1, 0)
            )
        else:
            m_idx = convert_block_idx // k_div_block_k
            k_idx = convert_block_idx % k_div_block_k
            
            in_m_offset = m_idx * BLOCK_M
            out_offset = (m_idx * k_div_block_k + k_idx) * BLOCK_M * BLOCK_K
            
            in_block_ptr = tl.make_block_ptr(
                base=a_in,
                shape=(M, K),
                strides=(stride_am, stride_ak),
                offsets=(in_m_offset, k_idx * BLOCK_K),
                block_shape=(BLOCK_M, BLOCK_K),
                order=(1, 0)
            )
            
            out_block_ptr = tl.make_block_ptr(
                base=a_out + out_offset,
                shape=(BLOCK_M, BLOCK_K),
                strides=(BLOCK_K, 1),
                offsets=(0, 0),
                block_shape=(BLOCK_M, BLOCK_K),
                order=(1, 0)
            )
        
        a_block = tl.load(in_block_ptr, boundary_check=(0, 1))
        tl.store(out_block_ptr, a_block, boundary_check=(0, 1))
    
    # Then convert B matrix
    if NEED_SPLIT_B:
        total_b_convert_blocks = k_div_block_k * n_div_block_n * 2
    else:
        total_b_convert_blocks = k_div_block_k * n_div_block_n
    
    for convert_block_idx in range(pid, total_b_convert_blocks, CORE_NUM):
        if NEED_SPLIT_B:
            pair_idx = convert_block_idx // 2
            k_idx = pair_idx // n_div_block_n
            n_idx = pair_idx % n_div_block_n
            
            in_k_offset = k_idx * BLOCK_K + (convert_block_idx % 2) * half_block_k
            out_offset = (k_idx * n_div_block_n + n_idx) * BLOCK_K * BLOCK_N
            
            in_block_ptr = tl.make_block_ptr(
                base=b_in,
                shape=(K, N),
                strides=(N, 1),
                offsets=(in_k_offset, n_idx * BLOCK_N),
                block_shape=(half_block_k, BLOCK_N),
                order=(1, 0)
            )
            
            out_block_ptr = tl.make_block_ptr(
                base=b_out + out_offset,
                shape=(BLOCK_K, BLOCK_N),
                strides=(BLOCK_N, 1),
                offsets=((convert_block_idx % 2) * half_block_k, 0),
                block_shape=(half_block_k, BLOCK_N),
                order=(1, 0)
            )
        else:
            k_idx = convert_block_idx // n_div_block_n
            n_idx = convert_block_idx % n_div_block_n
            
            in_k_offset = k_idx * BLOCK_K
            out_offset = (k_idx * n_div_block_n + n_idx) * BLOCK_K * BLOCK_N
            
            in_block_ptr = tl.make_block_ptr(
                base=b_in,
                shape=(K, N),
                strides=(N, 1),
                offsets=(in_k_offset, n_idx * BLOCK_N),
                block_shape=(BLOCK_K, BLOCK_N),
                order=(1, 0)
            )
            
            out_block_ptr = tl.make_block_ptr(
                base=b_out + out_offset,
                shape=(BLOCK_K, BLOCK_N),
                strides=(BLOCK_N, 1),
                offsets=(0, 0),
                block_shape=(BLOCK_K, BLOCK_N),
                order=(1, 0)
            )
        
        b_block = tl.load(in_block_ptr, boundary_check=(0, 1))
        tl.store(out_block_ptr, b_block, boundary_check=(0, 1))
    
    # ========== Sync between Phase 1 and Phase 2 ==========
    tl.sync_block_set("vector", "cube", 0)
    tl.sync_block_wait("vector", "cube", 0)
    triton.language.sync_block_all("all_cube", 0)
    
    # ========== Phase 2: GEMM Computation ==========
    num_m_blocks = (M + BLOCK_M - 1) // BLOCK_M
    num_n_blocks = (N + BLOCK_N - 1) // BLOCK_N
    num_blocks = num_m_blocks * num_n_blocks
    
    for block_idx in range(pid, num_blocks, CORE_NUM):
        pid_m = block_idx // num_n_blocks
        pid_n = block_idx % num_n_blocks
        
        c_ptr = tl.make_block_ptr(
            base=c,
            shape=(M, N),
            strides=(stride_cm, stride_cn),
            offsets=(pid_m * BLOCK_M, pid_n * BLOCK_N),
            block_shape=(BLOCK_M, BLOCK_N),
            order=(1, 0)
        )
        
        acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
        
        for k in range(0, K, BLOCK_K):
            # Load A first
            k_idx_inner = k // BLOCK_K
            a_offset = (pid_m * k_div_block_k + k_idx_inner) * BLOCK_M * BLOCK_K
            
            a_block_ptr = tl.make_block_ptr(
                base=a_out + a_offset,
                shape=(BLOCK_M, BLOCK_K),
                strides=(BLOCK_K, 1),
                offsets=(0, 0),
                block_shape=(BLOCK_M, BLOCK_K),
                order=(1, 0)
            )
            a_block = tl.load(a_block_ptr, boundary_check=(0, 1))
            tl.compile_hint(a_block, "dot_pad_only_k")
            
            # Then load B
            b_offset = (k_idx_inner * n_div_block_n + pid_n) * BLOCK_K * BLOCK_N
            
            b_block_ptr = tl.make_block_ptr(
                base=b_out + b_offset,
                shape=(BLOCK_K, BLOCK_N),
                strides=(BLOCK_N, 1),
                offsets=(0, 0),
                block_shape=(BLOCK_K, BLOCK_N),
                order=(1, 0)
            )
            b_block = tl.load(b_block_ptr, boundary_check=(0, 1))
            tl.compile_hint(b_block, "dot_pad_only_k")
            
            acc += tl.dot(a_block, b_block)
        
        output = acc.to(tl.float16)
        tl.store(c_ptr, output, boundary_check=(0, 1))

def gemm(a, b):
    M, K = a.shape
    K_from_b, N = b.shape

    c = torch.empty((M, N), dtype=torch.float16, device=a.device)

    config = AUTOTUNE_CONFIGS[0]
    BLOCK_SIZE_M = config.kwargs['BLOCK_M']
    BLOCK_SIZE_N = config.kwargs['BLOCK_N']
    BLOCK_SIZE_K = config.kwargs['BLOCK_K']

    m_div_block_m = M // BLOCK_SIZE_M
    k_div_block_k = K // BLOCK_SIZE_K
    n_div_block_n = N // BLOCK_SIZE_N

    a_out = torch.empty(m_div_block_m * k_div_block_k * BLOCK_SIZE_M * BLOCK_SIZE_K,
                        dtype=a.dtype, device=a.device)
    b_out = torch.empty(k_div_block_k * n_div_block_n * BLOCK_SIZE_K * BLOCK_SIZE_N,
                        dtype=b.dtype, device=b.device)

    BLOCK_SIZE_THRESHOLD = 64 * 1024
    NEED_SPLIT_A = (BLOCK_SIZE_M * BLOCK_SIZE_K * 2) > BLOCK_SIZE_THRESHOLD
    NEED_SPLIT_B = (BLOCK_SIZE_N * BLOCK_SIZE_K * 2) > BLOCK_SIZE_THRESHOLD
    half_block_m = BLOCK_SIZE_M // 2 if NEED_SPLIT_A else BLOCK_SIZE_M
    half_block_k = BLOCK_SIZE_K // 2 if NEED_SPLIT_B else BLOCK_SIZE_K

    device = torch_npu.npu.current_device()
    properties = driver.active.utils.get_device_properties(device)
    CORE_NUM = properties["num_aicore"]
    grid = (CORE_NUM,)

    gemm_aw_fuse_kernel[grid](
        a, a_out, b, b_out, c, M, N, K,
        a.stride(0), a.stride(1),
        c.stride(0), c.stride(1),
        CORE_NUM=CORE_NUM,
        half_block_m=half_block_m,
        half_block_k=half_block_k,
        NEED_SPLIT_A=NEED_SPLIT_A,
        NEED_SPLIT_B=NEED_SPLIT_B,
    )

    return c

def main():
    device = torch.device("npu")

    M = 4096
    N = 4096
    K = 7168

    a = torch.randint(-5, 6, (M, K), device=device).to(torch.float16)
    b = torch.randint(-5, 6, (K, N), device=device).to(torch.float16)

    output_triton = gemm(a, b)

    a_fp32 = a.to(torch.float32)
    b_fp32 = b.to(torch.float32)
    output_torch = torch.matmul(a_fp32, b_fp32).to(torch.float16)

    abs_error = torch.abs(output_triton - output_torch)
    rel_error = abs_error / (torch.abs(output_torch) + 1e-8)

    within_tolerance = rel_error <= 1e-3
    num_within_tolerance = within_tolerance.sum().item()
    total_elements = output_triton.numel()

    accuracy_rate = num_within_tolerance / total_elements
    error_rate = 1.0 - accuracy_rate

    print(f"Error rate: {error_rate:.4f}")

    if error_rate <= 0.001:
        print("Test passed!")
    else:
        print("Test failed!")

if __name__ == "__main__":
    main()
