import torch
import triton
import triton.language as tl
import triton.runtime.driver as driver
import torch_npu


AUTOTUNE_CONFIGS = [
    triton.Config({'BLOCK_M': 128, 'BLOCK_N': 128, 'BLOCK_K': 256, 'GROUP_SIZE': 4}),
]


@triton.autotune(
    configs=AUTOTUNE_CONFIGS,
    key=['M', 'N', 'K'],
)
@triton.jit
def gemm_int8_koffset_diagonal_a_fuse_kernel(
    a_in, a_out, b, c, M, N, K,
    stride_am, stride_ak,
    stride_bk, stride_bn,
    stride_cm, stride_cn,
    BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr,
    GROUP_SIZE: tl.constexpr,
    CORE_NUM: tl.constexpr,
    half_block_m: tl.constexpr,
    NEED_SPLIT: tl.constexpr,
):
    pid = tl.program_id(0)

    m_div_block_m = M // BLOCK_M
    k_div_block_k = K // BLOCK_K

    if NEED_SPLIT:
        total_convert_blocks = m_div_block_m * k_div_block_k * 2
    else:
        total_convert_blocks = m_div_block_m * k_div_block_k

    for convert_block_idx in range(pid, total_convert_blocks, CORE_NUM):
        if NEED_SPLIT:
            pair_idx = convert_block_idx // 2
            m_idx = pair_idx // k_div_block_k
            k_idx = pair_idx % k_div_block_k

            in_m_offset = m_idx * BLOCK_M + (convert_block_idx % 2) * half_block_m
            out_offset = (m_idx * k_div_block_k + k_idx) * BLOCK_M * BLOCK_K

            in_block_ptr = tl.make_block_ptr(
                base=a_in,
                shape=(M, K),
                strides=(stride_am, stride_ak),
                offsets=(in_m_offset, k_idx * BLOCK_K),
                block_shape=(half_block_m, BLOCK_K),
                order=(1, 0),
            )

            out_block_ptr = tl.make_block_ptr(
                base=a_out + out_offset,
                shape=(BLOCK_M, BLOCK_K),
                strides=(BLOCK_K, 1),
                offsets=((convert_block_idx % 2) * half_block_m, 0),
                block_shape=(half_block_m, BLOCK_K),
                order=(1, 0),
            )
        else:
            m_idx = convert_block_idx // k_div_block_k
            k_idx = convert_block_idx % k_div_block_k

            in_m_offset = m_idx * BLOCK_M
            out_offset = (m_idx * k_div_block_k + k_idx) * BLOCK_M * BLOCK_K

            in_block_ptr = tl.make_block_ptr(
                base=a_in,
                shape=(M, K),
                strides=(stride_am, stride_ak),
                offsets=(in_m_offset, k_idx * BLOCK_K),
                block_shape=(BLOCK_M, BLOCK_K),
                order=(1, 0),
            )

            out_block_ptr = tl.make_block_ptr(
                base=a_out + out_offset,
                shape=(BLOCK_M, BLOCK_K),
                strides=(BLOCK_K, 1),
                offsets=(0, 0),
                block_shape=(BLOCK_M, BLOCK_K),
                order=(1, 0),
            )

        a_block = tl.load(in_block_ptr, boundary_check=(0, 1))
        tl.store(out_block_ptr, a_block, boundary_check=(0, 1))

    tl.sync_block_set("vector", "cube", 0)
    tl.sync_block_wait("vector", "cube", 0)
    triton.language.sync_block_all("all_cube", 0)

    num_pid_m = tl.cdiv(M, BLOCK_M)
    num_pid_n = tl.cdiv(N, BLOCK_N)

    groups_m = tl.cdiv(num_pid_m, GROUP_SIZE)
    groups_n = tl.cdiv(num_pid_n, GROUP_SIZE)
    num_groups = groups_m * groups_n

    tiles_per_group = GROUP_SIZE * GROUP_SIZE

    total_virtual_tiles = num_groups * tiles_per_group

    num_m_blocks = num_pid_m
    num_n_blocks = num_pid_n
    num_blocks = num_m_blocks * num_n_blocks

    for block_idx in range(pid, total_virtual_tiles, CORE_NUM):
        group_idx = block_idx // tiles_per_group
        in_group_idx = block_idx % tiles_per_group

        group_m = group_idx // groups_n
        group_n = group_idx % groups_n

        i = in_group_idx % GROUP_SIZE
        j = in_group_idx // GROUP_SIZE
        local_m = i
        local_n = (i + j) % GROUP_SIZE

        block_m = group_m * GROUP_SIZE + local_m
        block_n = group_n * GROUP_SIZE + local_n

        if block_m < num_pid_m and block_n < num_pid_n:
            c_ptr = tl.make_block_ptr(
                base=c,
                shape=(M, N),
                strides=(stride_cm, stride_cn),
                offsets=(block_m * BLOCK_M, block_n * BLOCK_N),
                block_shape=(BLOCK_M, BLOCK_N),
                order=(1, 0),
            )

            acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.int32)

            num_k_blocks = tl.cdiv(K, BLOCK_K)
            k_offset = (2 * block_idx) % num_k_blocks

            for k_iter in range(num_k_blocks):
                k_idx = (k_iter + k_offset) % num_k_blocks
                current_k = k_idx * BLOCK_K

                a_out_offset = (block_m * k_div_block_k + k_idx) * BLOCK_M * BLOCK_K
                a_block_ptr = tl.make_block_ptr(
                    base=a_out + a_out_offset,
                    shape=(BLOCK_M, BLOCK_K),
                    strides=(BLOCK_K, 1),
                    offsets=(0, 0),
                    block_shape=(BLOCK_M, BLOCK_K),
                    order=(1, 0),
                )

                b_ptr = tl.make_block_ptr(
                    base=b,
                    shape=(K, N),
                    strides=(stride_bk, stride_bn),
                    offsets=(current_k, block_n * BLOCK_N),
                    block_shape=(BLOCK_K, BLOCK_N),
                    order=(1, 0),
                )

                a_block = tl.load(a_block_ptr, boundary_check=(0, 1))
                tl.compile_hint(a_block, "dot_pad_only_k")
                b_block = tl.load(b_ptr, boundary_check=(0, 1))
                tl.compile_hint(b_block, "dot_pad_only_k")
                acc += tl.dot(a_block, b_block)

            output = acc.to(tl.float16)
            tl.store(c_ptr, output, boundary_check=(0, 1))


def gemm(a, b):
    M, K = a.shape
    K, N = b.shape

    c = torch.empty((M, N), dtype=torch.float16, device=a.device)

    config = AUTOTUNE_CONFIGS[0]
    BLOCK_SIZE_M = config.kwargs['BLOCK_M']
    BLOCK_SIZE_K = config.kwargs['BLOCK_K']

    m_div_block_m = M // BLOCK_SIZE_M
    k_div_block_k = K // BLOCK_SIZE_K
    a_out = torch.empty(m_div_block_m * k_div_block_k * BLOCK_SIZE_M * BLOCK_SIZE_K,
                        dtype=a.dtype, device=a.device)

    BLOCK_SIZE_THRESHOLD = 64 * 1024
    NEED_SPLIT = (BLOCK_SIZE_M * BLOCK_SIZE_K) > BLOCK_SIZE_THRESHOLD
    half_block_m = BLOCK_SIZE_M // 2 if NEED_SPLIT else BLOCK_SIZE_M

    device = torch_npu.npu.current_device()
    properties = driver.active.utils.get_device_properties(device)
    CORE_NUM = properties["num_aicore"]
    grid = (CORE_NUM,)

    gemm_int8_koffset_diagonal_a_fuse_kernel[grid](
        a, a_out, b, c, M, N, K,
        a.stride(0), a.stride(1),
        b.stride(0), b.stride(1),
        c.stride(0), c.stride(1),
        CORE_NUM=CORE_NUM,
        half_block_m=half_block_m,
        NEED_SPLIT=NEED_SPLIT,
    )

    return c


def main():
    device = torch.device("npu")

    M = 4096
    N = 128
    K = 7168

    a = torch.randint(-5, 6, (M, K), device=device).to(torch.int8)
    b = torch.randint(-5, 6, (K, N), device=device).to(torch.int8)

    output_triton = gemm(a, b)

    a_fp32 = a.to(torch.float32)
    b_fp32 = b.to(torch.float32)
    output_torch = torch.matmul(a_fp32, b_fp32).to(torch.float16)

    abs_error = torch.abs(output_triton - output_torch)
    rel_error = abs_error / (torch.abs(output_torch) + 1e-8)

    within_tolerance = rel_error <= 1e-3
    num_within_tolerance = within_tolerance.sum().item()
    total_elements = output_triton.numel()

    accuracy_rate = num_within_tolerance / total_elements
    error_rate = 1.0 - accuracy_rate

    print(f"Error rate: {error_rate:.4f}")

    if error_rate <= 0.001:
        print("Test passed!")
    else:
        print("Test failed!")


if __name__ == "__main__":
    main()
