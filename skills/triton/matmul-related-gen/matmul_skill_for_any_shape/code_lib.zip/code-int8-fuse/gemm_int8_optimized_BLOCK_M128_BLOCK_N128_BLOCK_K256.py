import torch
import triton
import triton.language as tl
import triton.runtime.driver as driver
import torch_npu

AUTOTUNE_CONFIGS = [
    triton.Config({'BLOCK_M': 128, 'BLOCK_N': 128, 'BLOCK_K': 256}),
]

@triton.autotune(
    configs=AUTOTUNE_CONFIGS,
    key=['M', 'N', 'K'],
)
@triton.jit
def gemm_int8_optimized(
    a, b, c, M, N, K,
    stride_am, stride_ak,
    stride_bk, stride_bn,
    stride_cm, stride_cn,
    BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr,
    CORE_NUM
):
    pid = tl.program_id(0)

    num_m_blocks = (M + BLOCK_M - 1) // BLOCK_M
    num_n_blocks = (N + BLOCK_N - 1) // BLOCK_N
    num_blocks = num_m_blocks * num_n_blocks

    for block_idx in range(pid, num_blocks, CORE_NUM):
        pid_m = block_idx // num_n_blocks
        pid_n = block_idx % num_n_blocks

        a_ptr = tl.make_block_ptr(
            base=a,
            shape=(M, K),
            strides=(stride_am, stride_ak),
            offsets=(pid_m * BLOCK_M, 0),
            block_shape=(BLOCK_M, BLOCK_K),
            order=(1, 0),
        )

        b_ptr = tl.make_block_ptr(
            base=b,
            shape=(K, N),
            strides=(stride_bk, stride_bn),
            offsets=(0, pid_n * BLOCK_N),
            block_shape=(BLOCK_K, BLOCK_N),
            order=(1, 0),
        )

        c_ptr = tl.make_block_ptr(
            base=c,
            shape=(M, N),
            strides=(stride_cm, stride_cn),
            offsets=(pid_m * BLOCK_M, pid_n * BLOCK_N),
            block_shape=(BLOCK_M, BLOCK_N),
            order=(1, 0),
        )

        acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.int32)

        for k in range(0, K, BLOCK_K):
            a_block = tl.load(a_ptr, boundary_check=(0, 1))
            tl.compile_hint(a_block, "dot_pad_only_k")
            b_block = tl.load(b_ptr, boundary_check=(0, 1))
            tl.compile_hint(b_block, "dot_pad_only_k")
            acc += tl.dot(a_block, b_block)

            a_ptr = tl.advance(a_ptr, (0, BLOCK_K))
            b_ptr = tl.advance(b_ptr, (BLOCK_K, 0))

        output = acc.to(tl.float16)
        tl.store(c_ptr, output, boundary_check=(0, 1))

def gemm(a, b):
    M, K = a.shape
    K, N = b.shape

    c = torch.empty((M, N), dtype=torch.float16, device=a.device)

    device = torch_npu.npu.current_device()
    properties = driver.active.utils.get_device_properties(device)
    CORE_NUM = properties["num_aicore"]

    grid = (CORE_NUM,)

    stride_am = a.stride(0)
    stride_ak = a.stride(1)
    stride_bk = b.stride(0)
    stride_bn = b.stride(1)
    stride_cm = c.stride(0)
    stride_cn = c.stride(1)

    gemm_int8_optimized[grid](
        a, b, c, M, N, K,
        stride_am, stride_ak,
        stride_bk, stride_bn,
        stride_cm, stride_cn,
        CORE_NUM=CORE_NUM
    )

    return c

def main():
    device = torch.device("npu")

    M = 128
    N = 4096
    K = 7168

    a = torch.randint(-5, 6, (M, K), device=device).to(torch.int8)
    b = torch.randint(-5, 6, (K, N), device=device).to(torch.int8)

    output_triton = gemm(a, b)

    a_fp32 = a.to(torch.float32)
    b_fp32 = b.to(torch.float32)
    output_torch = torch.matmul(a_fp32, b_fp32).to(torch.float16)

    abs_error = torch.abs(output_triton - output_torch)
    rel_error = abs_error / (torch.abs(output_torch) + 1e-8)

    within_tolerance = rel_error <= 1e-3
    num_within_tolerance = within_tolerance.sum().item()
    total_elements = output_triton.numel()

    accuracy_rate = num_within_tolerance / total_elements
    error_rate = 1.0 - accuracy_rate

    print(f"Error rate: {error_rate:.4f}")

    if error_rate <= 0.001:
        print("Test passed!")
    else:
        print("Test failed!")

if __name__ == "__main__":
    main()