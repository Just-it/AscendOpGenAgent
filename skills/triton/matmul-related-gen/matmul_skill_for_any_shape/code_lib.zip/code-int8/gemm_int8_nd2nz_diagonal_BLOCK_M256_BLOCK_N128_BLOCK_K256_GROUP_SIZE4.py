import torch
import triton
import triton.language as tl
import triton.runtime.driver as driver
import torch_npu

AUTOTUNE_CONFIGS = [
    triton.Config({'BLOCK_M': 256, 'BLOCK_N': 128, 'BLOCK_K': 256, 'GROUP_SIZE': 4}),
]

def convert_b_matrix(b: torch.Tensor, block_k: int, block_n: int):
    K, N = b.shape
    assert K % block_k == 0, f'K ({K}) must be divisible by block_k ({block_k})'
    assert N % block_n == 0, f'N ({N}) must be divisible by block_n ({block_n})'
    
    k_div_block_k = K // block_k
    n_div_block_n = N // block_n
    
    b_reshaped = b.view(k_div_block_k, block_k, n_div_block_n, block_n)
    b_optimized = b_reshaped.permute(0, 2, 1, 3).contiguous()
    
    return b_optimized

@triton.autotune(
    configs=AUTOTUNE_CONFIGS,
    key=['M', 'N', 'K'],
)
@triton.jit
def gemm_int8_nd2nz_diagonal(
    a, b, c, M, N, K,
    stride_am, stride_ak,
    stride_b_k_div_block_k, stride_b_n_div_block_n,
    stride_cm, stride_cn,
    BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr,
    GROUP_SIZE: tl.constexpr,
    CORE_NUM
):
    pid = tl.program_id(0)

    num_pid_m = tl.cdiv(M, BLOCK_M)
    num_pid_n = tl.cdiv(N, BLOCK_N)

    groups_m = tl.cdiv(num_pid_m, GROUP_SIZE)
    groups_n = tl.cdiv(num_pid_n, GROUP_SIZE)
    num_groups = groups_m * groups_n

    tiles_per_group = GROUP_SIZE * GROUP_SIZE

    total_virtual_tiles = num_groups * tiles_per_group

    num_m_blocks = num_pid_m
    num_n_blocks = num_pid_n
    num_blocks = num_m_blocks * num_n_blocks

    for block_idx in range(pid, total_virtual_tiles, CORE_NUM):
        group_idx = block_idx // tiles_per_group
        in_group_idx = block_idx % tiles_per_group

        group_m = group_idx // groups_n
        group_n = group_idx % groups_n

        i = in_group_idx % GROUP_SIZE
        j = in_group_idx // GROUP_SIZE
        local_m = i
        local_n = (i + j) % GROUP_SIZE

        block_m = group_m * GROUP_SIZE + local_m
        block_n = group_n * GROUP_SIZE + local_n

        if block_m < num_pid_m and block_n < num_pid_n:
            a_ptr = tl.make_block_ptr(
                base=a,
                shape=(M, K),
                strides=(stride_am, stride_ak),
                offsets=(block_m * BLOCK_M, 0),
                block_shape=(BLOCK_M, BLOCK_K),
                order=(1, 0),
            )

            c_ptr = tl.make_block_ptr(
                base=c,
                shape=(M, N),
                strides=(stride_cm, stride_cn),
                offsets=(block_m * BLOCK_M, block_n * BLOCK_N),
                block_shape=(BLOCK_M, BLOCK_N),
                order=(1, 0),
            )

            acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.int32)

            for k in range(0, K, BLOCK_K):
                a_block = tl.load(a_ptr, boundary_check=(0, 1))
                tl.compile_hint(a_block, "dot_pad_only_k")
                
                k_div_block_k = k // BLOCK_K
                n_div_block_n = block_n
                
                b_offset = k_div_block_k * stride_b_k_div_block_k + n_div_block_n * stride_b_n_div_block_n
                b_raw = tl.load(b + b_offset + tl.arange(0, BLOCK_K * BLOCK_N))
                b_block = b_raw.reshape(BLOCK_K, BLOCK_N)
                tl.compile_hint(b_block, "dot_pad_only_k")
                
                acc += tl.dot(a_block, b_block)

                a_ptr = tl.advance(a_ptr, (0, BLOCK_K))

            output = acc.to(tl.float16)
            tl.store(c_ptr, output, boundary_check=(0, 1))

def gemm(a, b):
    M, K = a.shape
    K_from_b, N = b.shape

    c = torch.empty((M, N), dtype=torch.float16, device=a.device)

    device = torch_npu.npu.current_device()
    properties = driver.active.utils.get_device_properties(device)
    CORE_NUM = properties["num_aicore"]

    config = AUTOTUNE_CONFIGS[0]
    BLOCK_SIZE_N = config.kwargs['BLOCK_N']
    BLOCK_SIZE_K = config.kwargs['BLOCK_K']

    b_optimized = convert_b_matrix(b, block_k=BLOCK_SIZE_K, block_n=BLOCK_SIZE_N)

    k_div_block_k = K // BLOCK_SIZE_K
    n_div_block_n = N // BLOCK_SIZE_N

    stride_b_n_div_block_n = BLOCK_SIZE_K * BLOCK_SIZE_N
    stride_b_k_div_block_k = n_div_block_n * stride_b_n_div_block_n

    grid = (CORE_NUM,)

    stride_am = a.stride(0)
    stride_ak = a.stride(1)
    stride_cm = c.stride(0)
    stride_cn = c.stride(1)

    gemm_int8_nd2nz_diagonal[grid](
        a, b_optimized, c, M, N, K,
        stride_am, stride_ak,
        stride_b_k_div_block_k, stride_b_n_div_block_n,
        stride_cm, stride_cn,
        CORE_NUM=CORE_NUM
    )

    return c

def main():
    device = torch.device("npu")

    M = 128
    N = 4096
    K = 7168

    a = torch.randint(-5, 6, (M, K), device=device).to(torch.int8)
    b = torch.randint(-5, 6, (K, N), device=device).to(torch.int8)

    output_triton = gemm(a, b)

    a_fp32 = a.to(torch.float32)
    b_fp32 = b.to(torch.float32)
    output_torch = torch.matmul(a_fp32, b_fp32).to(torch.float16)

    abs_error = torch.abs(output_triton - output_torch)
    rel_error = abs_error / (torch.abs(output_torch) + 1e-8)

    within_tolerance = rel_error <= 1e-3
    num_within_tolerance = within_tolerance.sum().item()
    total_elements = output_triton.numel()

    accuracy_rate = num_within_tolerance / total_elements
    error_rate = 1.0 - accuracy_rate

    print(f"Error rate: {error_rate:.4f}")

    if error_rate <= 0.001:
        print("Test passed!")
    else:
        print("Test failed!")

if __name__ == "__main__":
    main()